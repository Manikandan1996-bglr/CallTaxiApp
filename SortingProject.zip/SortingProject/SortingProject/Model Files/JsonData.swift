//
//	Data.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation


class Data : NSObject, NSCoding{

	var employeeAge : Int!
	var employeeName : String!
	var employeeSalary : Int!
	var id : Int!
	var profileImage : String!


	/**
	 * Instantiate the instance using the passed dictionary values to set the properties values
	 */
	init(fromDictionary dictionary: [String:Any]){
		employeeAge = dictionary["employee_age"] as? Int
		employeeName = dictionary["employee_name"] as? String
		employeeSalary = dictionary["employee_salary"] as? Int
		id = dictionary["id"] as? Int
		profileImage = dictionary["profile_image"] as? String
	}

	/**
	 * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
	 */
	func toDictionary() -> [String:Any]
	{
		var dictionary = [String:Any]()
		if employeeAge != nil{
			dictionary["employee_age"] = employeeAge
		}
		if employeeName != nil{
			dictionary["employee_name"] = employeeName
		}
		if employeeSalary != nil{
			dictionary["employee_salary"] = employeeSalary
		}
		if id != nil{
			dictionary["id"] = id
		}
		if profileImage != nil{
			dictionary["profile_image"] = profileImage
		}
		return dictionary
	}

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
	{
         employeeAge = aDecoder.decodeObject(forKey: "employee_age") as? Int
         employeeName = aDecoder.decodeObject(forKey: "employee_name") as? String
         employeeSalary = aDecoder.decodeObject(forKey: "employee_salary") as? Int
         id = aDecoder.decodeObject(forKey: "id") as? Int
         profileImage = aDecoder.decodeObject(forKey: "profile_image") as? String

	}

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    @objc func encode(with aCoder: NSCoder)
	{
		if employeeAge != nil{
			aCoder.encode(employeeAge, forKey: "employee_age")
		}
		if employeeName != nil{
			aCoder.encode(employeeName, forKey: "employee_name")
		}
		if employeeSalary != nil{
			aCoder.encode(employeeSalary, forKey: "employee_salary")
		}
		if id != nil{
			aCoder.encode(id, forKey: "id")
		}
		if profileImage != nil{
			aCoder.encode(profileImage, forKey: "profile_image")
		}

	}

}