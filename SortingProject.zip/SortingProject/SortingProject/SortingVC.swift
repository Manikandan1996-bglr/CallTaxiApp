//
//  SortingVC.swift
//  SortingProject
//
//  Created by Velozion Mac on 03/July/2019A.
//

import UIKit
import Foundation
class SortingVC: UIViewController {
    
    var jsonData: [[String: Any]] = []
    var filterJsonData: [[String: Any]] = []
    var searching = false
    @IBOutlet weak var SortingTV: UITableView!
    @IBOutlet var searchBar: UISearchBar!
    override func viewDidLoad() {
        super.viewDidLoad()
        getJsonInfo()
        searchBar.delegate = self
        searchBar.placeholder = "Search Employee name"
    }
    
    func getJsonInfo() {
        getResponse { (result) in
            switch result {
            case .success(let response):
                for data in response["data"] as! [[String: Any]] {
                    self.jsonData.append(data)
                }
            case .failure(let error):
                print(error)
            }
            DispatchQueue.main.async {
                self.SortingTV.reloadData()
            }
        }
    }
    
    @IBAction func LowToHighTapped(_ sender: Any) {
        jsonData = self.jsonData.sorted { ($0["employee_salary"] as! Int) < ($1["employee_salary"] as! Int) }
        DispatchQueue.main.async {
            self.SortingTV.reloadData()
        }
    }
    
    @IBAction func highToLowTapped(_ sender: Any) {
        jsonData = self.jsonData.sorted { ($0["employee_salary"] as! Int) > ($1["employee_salary"] as! Int) }
        DispatchQueue.main.async {
            self.SortingTV.reloadData()
        }
    }
    
    @IBAction func searchBtnTapped(_ sender: Any) {
        SortingTV.tableHeaderView = searchBar
        let indexPath = IndexPath(row: 0, section: 0)
        SortingTV.selectRow(at: indexPath, animated: true, scrollPosition: .bottom)
    }
    
    @IBAction func ResetBtnTapped(_ sender: Any) {
        jsonData.removeAll()
        getJsonInfo()
        
    }
    
}

extension SortingVC: UITableViewDelegate, UITableViewDataSource {
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return filterJsonData.count
        } else {
            return jsonData.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "sortingCollectionCell") as! SortingCollectionCell
        var jsonDetails: [String : Any] = [:]
        if searching {
            jsonDetails = filterJsonData[indexPath.row]
        } else {
            jsonDetails = jsonData[indexPath.row]
        }
        cell.clienttNameLbl.text = jsonDetails["employee_name"] as? String
        cell.salaryLbl.text = String(jsonDetails["employee_salary"] as? Int ?? 1)
        cell.ageLbl.text = String(jsonDetails["employee_age"] as? Int ?? 1)
        return cell
    }
}

extension SortingVC: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let searchString = searchBar.text
        filterJsonData = jsonData.filter({ (item) -> Bool in
            let value: NSString = item["employee_name"] as! NSString
            return (value.range(of: searchString!, options: .caseInsensitive).location != NSNotFound)
        })
        searching = true
        SortingTV.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        searching = false
        SortingTV.reloadData()
        SortingTV.tableHeaderView = nil
    }
}

class SortingCollectionCell: UITableViewCell {
    @IBOutlet weak var clienttNameLbl: UILabel!
    @IBOutlet weak var salaryLbl: UILabel!
    @IBOutlet weak var ageLbl: UILabel!
    
}
